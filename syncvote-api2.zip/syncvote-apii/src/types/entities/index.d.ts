declare module 'entities' {}
